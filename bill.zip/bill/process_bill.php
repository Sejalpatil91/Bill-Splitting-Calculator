<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Connect to MySQL database
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "spliter"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$totalAmount = $_POST["total_amount"];
$numMembers = $_POST["num_members"];
$description = $_POST["description"];

// Calculate split amount
$splitAmount = $totalAmount / $numMembers;

// Retrieve selected usernames
$selectedUsernames = isset($_POST["user"]) ? $_POST["user"] : [];

// Convert selected usernames to a comma-separated string
$selectedUsersString = implode(", ", $selectedUsernames);

// Insert data into database
$sql = "INSERT INTO split_info (total_amount, num_members, split_amount, description, selected_users) VALUES ('$totalAmount', '$numMembers', '$splitAmount', '$description', '$selectedUsersString')";

if ($conn->query($sql) === TRUE) {
    echo "<div style='max-width: 600px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);'>";
    echo "<h2 style='color: #007bff; text-align: center;'>Bill Split Successfully Recorded</h2>";

    // Display total bill amount
    echo "<p style='text-align: center;'>Total Bill Amount: ₹." . number_format($totalAmount, 2) . "</p>";

    // Display selected users and their split amounts
    if (!empty($selectedUsernames)) {
        echo "<h3 style='color: #007bff;'>Selected Users and Their Split Amounts:</h3>";
        foreach ($selectedUsernames as $username) {
            echo "<p>$username Split Amount: ₹." . number_format($splitAmount, 2) . "</p>";
        }
    } else {
        echo "<p>No usernames selected.</p>";
    }

    // Print bill button
    echo "<div style='text-align: center;'>";
    echo "<button onclick='window.print()'>Print Bill</button>";
    echo "</div>";

    echo "</div>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>
