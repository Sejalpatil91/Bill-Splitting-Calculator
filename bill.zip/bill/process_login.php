<?php
session_start();
// Connect to MySQL database
$servername = "localhost";
$username = "root"; // Default username for XAMPP MySQL
$password = ""; // Default password for XAMPP MySQL
$database = "spliter"; // Name of the database you created
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST["username"];
$password = $_POST["password"];

// Check if the username and password match
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Authentication successful
    $_SESSION['username'] = $username;
    header("Location: bill_split.php");
    exit();
} else {
    // Authentication failed
    echo "Invalid username or password. <a href='index.php'>Try again</a>";
}

// Close database connection
$conn->close();
?>
