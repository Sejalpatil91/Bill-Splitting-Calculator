<!DOCTYPE html>
<html>
<head>
    <title>View Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Records</h2>
        <form method="post" action="">
            From Date: <input type="date" name="start_date">
            To Date: <input type="date" name="end_date">
            <input type="submit" name="submit" value="View Records">
        </form>

        <?php
        // Check if form is submitted
        if (isset($_POST["submit"])) {
            // Retrieve selected start and end dates from form
            $startDate = $_POST["start_date"];
            $endDate = $_POST["end_date"];

            // Connect to MySQL database
            $servername = "localhost";
            $username = "root"; // Default username for XAMPP MySQL
            $password = ""; // Default password for XAMPP MySQL
            $database = "spliter"; // Name of the database you created
            $conn = new mysqli($servername, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Modify the SQL query to retrieve records between the selected start and end dates
            $sql = "SELECT * FROM split_info WHERE DATE(created_at) BETWEEN '$startDate' AND '$endDate' ORDER BY created_at";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row in a table
                echo "<h3>Records from $startDate to $endDate:</h3>";
                echo "<table>";
                echo "<tr><th>Total Amount</th><th>Number of Members</th><th>Split Amount</th><th>Description</th><th>Selected Users</th><th>Created At</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    // Get selected users from the database and explode into an array
                    $selectedUsers = explode(',', $row["selected_users"]);
                    echo "<tr><td>" . $row["total_amount"] . "</td><td>" . $row["num_members"] . "</td><td>" . $row["split_amount"] . "</td><td>" . $row["description"] . "</td><td>" . implode(', ', $selectedUsers) . "</td><td>" . $row["created_at"] . "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "No records found between $startDate and $endDate";
            }

            // Close database connection
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
