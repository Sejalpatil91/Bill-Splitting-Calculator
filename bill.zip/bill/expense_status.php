<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Connect to MySQL database
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "spliter"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to update session variable for paid or unpaid expenses
function updateExpenseStatus($expenseIds, $status) {
    $_SESSION[$status] = $expenseIds;
}

// Check if form is submitted
if (isset($_POST['submit'])) {
    // Get the selected expense IDs for paid and unpaid expenses
    $paidExpenses = isset($_POST['paid']) ? $_POST['paid'] : [];
    $unpaidExpenses = isset($_POST['unpaid']) ? $_POST['unpaid'] : [];

    // Update session variables for paid and unpaid expenses
    updateExpenseStatus($paidExpenses, 'paid');
    updateExpenseStatus($unpaidExpenses, 'unpaid');
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Expense Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Expense Status</h2>
        <form method="post" action="">
            <table>
                <tr>
                    <th>Description</th>
                    <th>Date & Time</th>
                    <th>Paid</th>
                    <th>Unpaid</th>
                </tr>
                <?php
                // Retrieve expenses from the database
                $sql = "SELECT id, description, created_at FROM split_info";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Display expenses and checkboxes
                    while ($row = $result->fetch_assoc()) {
                        $expenseId = $row['id'];
                        $description = $row['description'];
                        $dateTime = $row['created_at'];
                        echo "<tr>";
                        echo "<td>$description</td>";
                        echo "<td>$dateTime</td>";
                        echo "<td><input type='checkbox' name='paid[]' value='$expenseId' ";
                        echo (isset($_SESSION['paid']) && in_array($expenseId, $_SESSION['paid'])) ? "checked" : "";
                        echo "></td>";
                        echo "<td><input type='checkbox' name='unpaid[]' value='$expenseId' ";
                        echo (isset($_SESSION['unpaid']) && in_array($expenseId, $_SESSION['unpaid'])) ? "checked" : "";
                        echo "></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No expenses found</td></tr>";
                }
                ?>
            </table>
            <input type="submit" name="submit" value="Update Status">
        </form>
    </div>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>
