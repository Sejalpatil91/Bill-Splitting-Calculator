-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 12:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spliter`
--

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `num_members` int(11) NOT NULL,
  `split_amount` decimal(10,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` enum('paid','unpaid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_status`
--

CREATE TABLE `expense_status` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` enum('paid','unpaid') NOT NULL DEFAULT 'unpaid',
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_users`
--

CREATE TABLE `expense_users` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT 0,
  `unpaid` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_user_status`
--

CREATE TABLE `expense_user_status` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `status` enum('paid','unpaid') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `split_record_id` int(11) NOT NULL,
  `member_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paid_users`
--

CREATE TABLE `paid_users` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_records`
--

CREATE TABLE `payment_records` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `paid_by` varchar(255) DEFAULT NULL,
  `status` enum('paid','unpaid') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `split_info`
--

CREATE TABLE `split_info` (
  `id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `num_members` int(11) NOT NULL,
  `split_amount` decimal(10,2) NOT NULL,
  `split_frequency` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Paid','Unpaid') DEFAULT 'Unpaid',
  `description` varchar(255) DEFAULT NULL,
  `selected_users` text DEFAULT NULL,
  `paid_users` text DEFAULT NULL,
  `unpaid_users` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `split_info`
--

INSERT INTO `split_info` (`id`, `total_amount`, `num_members`, `split_amount`, `split_frequency`, `created_at`, `updated_at`, `status`, `description`, `selected_users`, `paid_users`, `unpaid_users`) VALUES
(35, 1000.00, 2, 500.00, '', '2024-04-19 12:17:59', '2024-05-02 05:21:24', 'Unpaid', 'hotel', 'user1, user2, user9', '', ''),
(36, 1000.00, 3, 333.33, '', '2024-04-19 12:18:22', '2024-05-02 04:29:01', 'Unpaid', 'hotel', 'user1, user2, user9', NULL, NULL),
(37, 2000.00, 3, 666.67, '', '2024-04-19 12:20:23', '2024-05-02 02:53:01', 'Unpaid', 'rent', 'user1, user3, user12', '', ''),
(38, 2000.00, 3, 666.67, '', '2024-04-21 08:02:36', '2024-05-02 04:29:11', 'Unpaid', 'rent', 'user1, user2, user11', '', ''),
(39, 5000.00, 3, 1666.67, '', '2024-05-01 10:15:11', '2024-05-01 09:46:51', 'Unpaid', 'trip', 'user1, user2, user3', '', ''),
(40, 300.00, 2, 150.00, '', '2024-05-01 10:41:11', '2024-05-02 05:21:33', 'Unpaid', 'food', 'user1, user2', '', ''),
(41, 400.00, 2, 200.00, '', '2024-05-01 13:26:32', '2024-05-01 13:26:32', 'Unpaid', 'uber', 'user2, user3', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `unpaid_users`
--

CREATE TABLE `unpaid_users` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unpaid_users`
--

INSERT INTO `unpaid_users` (`id`, `expense_id`, `username`) VALUES
(1, 35, 'user1'),
(2, 40, 'user1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `payment_status` enum('paid','unpaid') DEFAULT 'unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `payment_status`) VALUES
(1, 'user1', 'password1', 'unpaid'),
(2, 'user2', 'password2', 'unpaid'),
(3, 'user3', 'password3', 'unpaid'),
(4, 'user4', 'password4', 'unpaid'),
(6, 'user9', '$2y$10$/ZufcA7czrX4SVKKemdt/ez3x/52GnZ2irwlO4inN74G1SmBS1fFe', 'unpaid'),
(7, 'user10', '$2y$10$RZ6Ij0IPXA1lecepnK.Jg.h80E08E04AyMtxjdi3I9XPgVeS2foOy', 'unpaid'),
(8, 'user11', '$2y$10$KzzRHfUwBbSlMdJjpxSfx.pUG9nsaGJrnUSdzPNpgPjmRCKtOcceS', 'unpaid'),
(9, 'user12', '$2y$10$FR0YKW5/tYXGz4y31/X3fulQCI5MD0MxOe3NlFsVDOJdi9tvnwKA.', 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `user_expenses`
--

CREATE TABLE `user_expenses` (
  `id` int(11) NOT NULL,
  `num_members` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('paid','unpaid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_expenses`
--

INSERT INTO `user_expenses` (`id`, `num_members`, `description`, `total_amount`, `status`, `created_at`) VALUES
(1, NULL, 'hotel', 500.00, 'unpaid', '2024-04-19 12:17:59'),
(2, NULL, 'hotel', 333.33, 'unpaid', '2024-04-19 12:18:22'),
(3, NULL, 'rent', 666.67, 'unpaid', '2024-04-19 12:20:23'),
(4, NULL, 'rent', 666.67, 'unpaid', '2024-04-21 08:02:36'),
(5, NULL, 'trip', 1666.67, 'unpaid', '2024-05-01 10:15:11'),
(6, NULL, 'food', 150.00, 'unpaid', '2024-05-01 10:41:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `expense_status`
--
ALTER TABLE `expense_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense_users`
--
ALTER TABLE `expense_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_id` (`expense_id`);

--
-- Indexes for table `expense_user_status`
--
ALTER TABLE `expense_user_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `split_record_id` (`split_record_id`);

--
-- Indexes for table `paid_users`
--
ALTER TABLE `paid_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_id` (`expense_id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `payment_records`
--
ALTER TABLE `payment_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_id` (`expense_id`);

--
-- Indexes for table `split_info`
--
ALTER TABLE `split_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unpaid_users`
--
ALTER TABLE `unpaid_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_id` (`expense_id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_expenses`
--
ALTER TABLE `user_expenses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_status`
--
ALTER TABLE `expense_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_users`
--
ALTER TABLE `expense_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_user_status`
--
ALTER TABLE `expense_user_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paid_users`
--
ALTER TABLE `paid_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_records`
--
ALTER TABLE `payment_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `split_info`
--
ALTER TABLE `split_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `unpaid_users`
--
ALTER TABLE `unpaid_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_expenses`
--
ALTER TABLE `user_expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `expense_users`
--
ALTER TABLE `expense_users`
  ADD CONSTRAINT `expense_users_ibfk_1` FOREIGN KEY (`expense_id`) REFERENCES `user_expenses` (`id`);

--
-- Constraints for table `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `members_ibfk_1` FOREIGN KEY (`split_record_id`) REFERENCES `split_info` (`id`);

--
-- Constraints for table `paid_users`
--
ALTER TABLE `paid_users`
  ADD CONSTRAINT `paid_users_ibfk_1` FOREIGN KEY (`expense_id`) REFERENCES `split_info` (`id`),
  ADD CONSTRAINT `paid_users_ibfk_2` FOREIGN KEY (`username`) REFERENCES `users` (`username`);

--
-- Constraints for table `payment_records`
--
ALTER TABLE `payment_records`
  ADD CONSTRAINT `payment_records_ibfk_1` FOREIGN KEY (`expense_id`) REFERENCES `split_info` (`id`);

--
-- Constraints for table `unpaid_users`
--
ALTER TABLE `unpaid_users`
  ADD CONSTRAINT `unpaid_users_ibfk_1` FOREIGN KEY (`expense_id`) REFERENCES `split_info` (`id`),
  ADD CONSTRAINT `unpaid_users_ibfk_2` FOREIGN KEY (`username`) REFERENCES `users` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
