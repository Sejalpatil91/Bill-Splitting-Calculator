<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Connect to MySQL database
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "spliter"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve list of users from the database
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Check if users exist
if ($result->num_rows > 0) {
    // Display the bill split form
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Bill Split</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
                color: #333;
                margin: 0;
                padding: 0;
            }
            .container {
                max-width: 600px;
                margin: 50px auto;
                padding: 20px;
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            h2 {
                color: #007bff;
                text-align: center;
            }
            form {
                margin-bottom: 20px;
            }
            input[type="text"],
            input[type="submit"],
            select {
                width: 100%;
                padding: 10px;
                margin: 5px 0;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }
            input[type="checkbox"] {
                margin-right: 5px;
            }
            input[type="submit"] {
                background-color: #007bff;
                color: #fff;
                cursor: pointer;
            }
            input[type="submit"]:hover {
                background-color: #0056b3;
            }
            a {
                display: block;
                text-align: center;
                color: #007bff;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Bill Split Calculator</h2>
            <form method="post" action="process_bill.php">
                Total Bill Amount: <input type="text" name="total_amount"><br><br>
                Number of Group Members: <input type="text" name="num_members"><br><br>
                Select Users to Split Bill:<br>
                <?php
                // Loop through each user to create checkboxes
                while ($row = $result->fetch_assoc()) {
                    echo '<input type="checkbox" name="user[]" value="' . $row["username"] . '"> ' . $row["username"] . '<br>';
                }
                ?>
                Description: <input type="text" name="description"><br><br>
                <input type="submit" name="submit" value="Split Bill">
            </form>
           
            <form method="post" action="view_expense.php">
                <input type="submit" name="view_expense" value="View My Expense">
            </form>
            <form method="post" action="expense_status.php">
                <input type="submit" name="status" value="Expense Status">
			</form>
            <a href="logout.php">Logout</a>
            <a href="view_records.php">View Records</a>	
				
			
            </form>
		
        </div>
    </body>
    </html>

    <?php
} else {
    // If no users exist, display an error message
    echo "No users found.";
}

// Close database connection
$conn->close();
?>
