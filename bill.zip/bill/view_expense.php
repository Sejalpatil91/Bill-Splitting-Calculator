<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Connect to MySQL database
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "spliter"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve username from the session
$username = $_SESSION['username'];

// Set default date range to one week ago to today
$startDate = date('Y-m-d', strtotime('-1 week'));
$endDate = date('Y-m-d');

// Check if form is submitted with date range
if (isset($_POST["submit"])) {
    // Retrieve selected start and end dates from form
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];
}

// Retrieve expenses for the selected user and date range from the database
$sql = "SELECT * FROM split_info WHERE selected_users LIKE '%$username%' AND DATE(created_at) BETWEEN '$startDate' AND '$endDate'";
$result = $conn->query($sql);

// Initialize total split amount
$totalSplitAmount = 0;

?>

<!DOCTYPE html>
<html>
<head>
    <title>View Expense</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Expense</h2>
        <form method="post" action="">
            From Date: <input type="date" name="start_date" value="<?php echo $startDate; ?>">
            To Date: <input type="date" name="end_date" value="<?php echo $endDate; ?>">
            <input type="submit" name="submit" value="View Expenses">
        </form>
        <?php
        // Check if any expenses found for the user
        if ($result->num_rows > 0) {
            // Output data of each row in a table
            echo "<table>";
            echo "<tr><th>Total Amount</th><th>Number of Members</th><th>My Expense</th><th>Description</th><th>Created At</th></tr>";
            while ($row = $result->fetch_assoc()) {
                // Determine status
                //$status = ($row["status"] == 1) ? "Paid" : "Unpaid";

                echo "<tr><td>" . $row["total_amount"] . "</td><td>" . $row["num_members"] . "</td><td>" . $row["split_amount"] . "</td><td>" . $row["description"] . "</td><td>" . $row["created_at"] . "</td></tr>";
                
                // Add split amount to total
                $totalSplitAmount += $row["split_amount"];
            }
            echo "</table>";

            // Display total split amount
            echo "<p>My Total Amount: ₹" . number_format($totalSplitAmount, 2) . "</p>";
        } else {
            echo "Select date to get expenses for  $username";
        }
        ?>
    </div>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>
