<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            color: #007bff;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post" action="process_login.php">
            Username: <input type="text" name="username"><br><br>
            Password: <input type="password" name="password"><br><br>
            <input type="submit" name="submit" value="Login">
        </form>

        <h3>Add User</h3>
        <form method="post" action="">
            Username: <input type="text" name="add_username"><br><br>
            Password: <input type="password" name="add_password"><br><br>
            <input type="submit" name="add_user" value="Add User">
        </form>

        <h3>Delete User</h3>
        <form method="post" action="">
            Username: <input type="text" name="delete_username"><br><br>
            <input type="submit" name="delete_user" value="Delete User">
        </form>
    </div>

    <?php
    // Database connection
    $servername = "localhost";
	$username = "root"; // Default username for XAMPP MySQL
	$password = ""; // Default password for XAMPP MySQL
	$database = "spliter"; // Name of the database you created
	$conn = new mysqli($servername, $username, $password, $database);
   

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Add User
    if (isset($_POST["add_user"])) {
        $add_username = $_POST["add_username"];
        $add_password = $_POST["add_password"];

        // Hash the password
        $hashed_password = password_hash($add_password, PASSWORD_DEFAULT);

        // Prepare and execute SQL statement to insert new user
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $add_username, $hashed_password);
        $stmt->execute();

        echo "User added successfully.";
    }

    // Delete User
    if (isset($_POST["delete_user"])) {
        $delete_username = $_POST["delete_username"];

        // Prepare and execute SQL statement to delete user
        $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        $stmt->bind_param("s", $delete_username);
        $stmt->execute();

        // Check if any rows were affected
        if ($stmt->affected_rows > 0) {
            echo "User deleted successfully.";
        } else {
            echo "User not found.";
        }
    }

    // Close database connection
    $conn->close();
    ?>
</body>
</html>
